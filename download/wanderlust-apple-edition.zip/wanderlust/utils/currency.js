/**
 * WanderLust — Currency configuration
 * ------------------------------------
 * All listing prices are stored in US Dollars (USD).
 * The Egyptian Pound (EGP) is a display currency converted at a
 * static reference rate (update EGP_PER_USD as needed).
 * Stripe checkout always charges in USD.
 */

const EGP_PER_USD = 48.5; // static display reference rate: 1 USD ≈ 48.5 EGP

const CURRENCIES = {
  USD: {
    code: "USD",
    symbol: "$",
    rate: 1,
    label: "US Dollar",
  },
  EGP: {
    code: "EGP",
    symbol: "E£",
    rate: EGP_PER_USD,
    label: "Egyptian Pound",
  },
};

const DEFAULT_CURRENCY = "USD";

/** Convert an amount from USD into the given currency code. */
function convert(amountUSD, code = DEFAULT_CURRENCY) {
  const c = CURRENCIES[code] || CURRENCIES[DEFAULT_CURRENCY];
  return amountUSD * c.rate;
}

/** Format an amount (stored in USD) as a display string, e.g. "$ 42" / "E£ 2,037". */
function formatPrice(amountUSD, code = DEFAULT_CURRENCY) {
  const c = CURRENCIES[code] || CURRENCIES[DEFAULT_CURRENCY];
  const value = Math.round(amountUSD * c.rate);
  return `${c.symbol} ${value.toLocaleString("en-US")}`;
}

module.exports = { CURRENCIES, DEFAULT_CURRENCY, EGP_PER_USD, convert, formatPrice };
