/* ============================================================
   WanderLust — Currency runtime (USD / EGP)
   ------------------------------------------------------------
   - Prices are stored & server-rendered in USD.
   - The navbar segmented control toggles USD <-> EGP.
   - Preference persists in localStorage ("wl-currency").
   - Any element with [data-price] holds a USD amount in its
     data attribute; its text is (re)formatted on load & switch.
   - A "wl:currency" CustomEvent is dispatched on switch so page
     scripts (e.g. the booking breakdown) can recompute.
   ============================================================ */

(function () {
  "use strict";

  var CFG = window.WL_CURRENCY || {
    currencies: { USD: { code: "USD", symbol: "$", rate: 1 } },
    default: "USD",
  };
  var CURRENCIES = CFG.currencies || { USD: { code: "USD", symbol: "$", rate: 1 } };
  var DEFAULT = CURRENCIES[CFG.default] ? CFG.default : "USD";
  var STORAGE_KEY = "wl-currency";

  var active = DEFAULT;
  try {
    var stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored && CURRENCIES[stored]) active = stored;
  } catch (e) { /* private mode etc. */ }

  function currency() { return active; }

  function convert(amountUSD, code) {
    var c = CURRENCIES[code || active] || CURRENCIES[DEFAULT];
    return amountUSD * c.rate;
  }

  function format(amountUSD, code) {
    var c = CURRENCIES[code || active] || CURRENCIES[DEFAULT];
    var value = Math.round(amountUSD * c.rate);
    return c.symbol + " " + value.toLocaleString("en-US");
  }

  /* Re-format every [data-price] element on the page. */
  function applyAll(root) {
    (root || document).querySelectorAll("[data-price]").forEach(function (el) {
      var usd = parseFloat(el.getAttribute("data-price"));
      if (!isNaN(usd)) el.textContent = format(usd);
    });
  }

  function syncSwitches() {
    document.querySelectorAll(".currency-switch").forEach(function (sw) {
      sw.setAttribute("data-active", active);
      sw.querySelectorAll(".currency-opt").forEach(function (btn) {
        var isActive = btn.getAttribute("data-currency") === active;
        btn.classList.toggle("is-active", isActive);
        btn.setAttribute("aria-pressed", isActive ? "true" : "false");
      });
    });
  }

  function setCurrency(code) {
    if (!CURRENCIES[code] || code === active) {
      syncSwitches();
      return;
    }
    active = code;
    try { window.localStorage.setItem(STORAGE_KEY, code); } catch (e) { /* ignore */ }
    syncSwitches();
    applyAll();
    document.dispatchEvent(new CustomEvent("wl:currency", { detail: { currency: active } }));
  }

  /* Wire the segmented controls once DOM is ready. */
  function init() {
    syncSwitches();
    applyAll();
    document.querySelectorAll(".currency-switch .currency-opt").forEach(function (btn) {
      btn.addEventListener("click", function () {
        setCurrency(btn.getAttribute("data-currency"));
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  /* Public API — page scripts (booking widget) use window.WL.fmt(...) */
  window.WL = {
    c: currency,
    convert: convert,
    fmt: format,
    set: setCurrency,
    apply: applyAll
  };
})();
