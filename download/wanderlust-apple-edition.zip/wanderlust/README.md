# Wanderlust

Wanderlust is a full-stack web application designed as an Airbnb clone, built using the MERN stack paradigm (Express, Node.js, MongoDB, and templated EJS views). It enables users to browse premium travel stays, view locations on interactive maps, leave reviews, and make mock reservations with integrated payment checkouts.

> **✨ Apple Edition theme** — the frontend has been redesigned with a premium, Apple-inspired look: a pure-white canvas, frosted-glass (glassmorphism) surfaces, SF-style typography, Apple-blue pill CTAs, hairline borders, and quiet, springy motion. See the [design system](#-design-system-apple-edition) section below.

---

## 🛠️ Tech Stack & Services
* **Backend**: Node.js & Express.js
* **Database**: MongoDB & Mongoose ODM
* **View Engine**: EJS (with `ejs-mate` layouts)
* **CSS Framework**: Bootstrap 5
* **Mapping API**: Mapbox SDK
* **Cloud Storage**: Cloudinary (for user-submitted listing images)
* **Payment Gateway**: Stripe API (Test Mode)

---

## 🚀 Key Features

* **Booking Reservation System**: Users can select Check-in and Check-out dates and reserve listings.
* **Dynamic Price Breakdown**: A sticky reservation widget on the listing details page calculates nights, rate totals, and final costs dynamically on the client side.
* **Stripe Payment Checkout (Test Mode)**: Reserves stays securely using mock checkout sessions.
* **Pre-Geocoded Listings**: Multi-city database seeder containing locations like Goa, Mumbai, Manali, Jaipur, Paris, NYC, Kyoto, and Bora Bora with pre-configured Mapbox coordinates.
* **Reviews & Ratings**: Leave star-ratings and written comments on listing pages, protected by owner authorization.
* **Responsive Layouts**: Designed with adaptive grid columns and smooth hover zoom scaling and shadow elevations.

---

## Apple Edition — Design & Currency

* **Premium white Apple-style theme** — deep glassmorphism (frosted cards, navbar, widgets), multi-layer ambient shadows, SF-inspired typography, and iOS-style segmented controls.
* **Frosted-glass field icons** — every form field carries its own color-coded glass icon tile (login/signup, listing create/edit, booking widget).
* **Currency system** — all prices are stored in **USD**; a live **USD ⇄ EGP toggle** in the navbar (iOS segmented control) switches display currency per visitor, persisted via `localStorage`. The Egyptian Pound is converted at a static reference rate defined in `utils/currency.js` (`EGP_PER_USD = 48.5`). **Stripe checkout always charges in USD.**
* **How it renders** — views render `"$"` prices server-side (`utils/currency.js`), and `public/js/currency.js` re-formats every `[data-price]` element client-side when the toggle changes.

---

## 📂 Project Structure
```
wanderlust/
├── controllers/
│   ├── listings.js         # Listings CRUD controllers
│   ├── reviews.js          # Reviews creation/deletion
│   ├── users.js            # Sign up / Login sessions
│   ├── bookings.js         # Check-in date validations & cost computations
│   └── payments.js         # Stripe Checkout sessions creation & confirmation
├── models/
│   ├── listing.js          # Mongoose Listing schema
│   ├── review.js           # Review schema
│   ├── user.js             # User profiles (passport-local-mongoose)
│   └── booking.js          # Travel bookings schema
├── routes/
│   ├── listing.js
│   ├── review.js
│   ├── user.js
│   └── booking.js          # Combined checkout, listing booking & payment routes
├── views/
│   ├── listings/           # index, show, edit, new views
│   ├── users/              # login, signup views
│   ├── bookings/           # index (my bookings list), success receipts
│   └── layouts/
│       └── boilerplate.ejs # Shared navbar/footer layout wrapper
├── public/                 # Static stylesheet assets & frontend map JS
├── init/
│   ├── data.js             # Multi-city database seeds
│   └── index.js            # Cleans DB, creates admin owner, inserts seeds
├── app.js                  # Main server setup and database connection
├── .env.example            # Configuration placeholders template
└── package.json
```

---

## 💻 Installation & Local Setup

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/siyam-bubere/WanderLust.git
   cd WanderLust
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment Variables**:
   Copy `.env.example` to `.env` and fill in your details:
   ```bash
   cp .env.example .env
   ```
   *(Note: The app will run locally out-of-the-box using local MongoDB and mock payment keys even if API keys are left as placeholders).*

4. **Seed the Database**:
   Clear existing records and insert default listings and the `admin` owner:
   ```bash
   node init/index.js
   ```

5. **Start Server**:
   ```bash
   node app.js
   ```
   Open `http://localhost:8080` in your web browser.

---

## 🔑 Seed User Logins
You can use the following default account to explore all features after running the seeder:
* **Username**: `admin`
* **Password**: `admin123`

---

## 🎨 Design System — "Apple Edition"

The UI was re-themed to feel like premium Apple product software — a white canvas with glassmorphism. All tokens live in `public/css/style.css` under `:root`, so you can retune the whole look from one place.

### Tokens
| Token | Value | Usage |
| --- | --- | --- |
| `--ink` / `--ink-2` / `--ink-3` | `#1d1d1f` / `#6e6e73` / `#86868b` | Apple system text grays |
| `--blue` | `#0071e3` | Apple-blue pill CTAs & accents |
| `--page` | `#fbfbfd` | Off-white canvas (apple.com background) |
| `--glass-bg` | `rgba(255,255,255,.58)` | Translucent surface + `backdrop-filter: blur(20px) saturate(180%)` |
| `--hairline` | `rgba(0,0,0,.08)` | 1px separators (nav, footer, toolbars) |
| `--r-pill` | `980px` | Infinite pill radius for buttons/chips |
| `--shadow-sm/md/lg` | layered rgba shadows | Quiet elevation on cards & sheets |

### Signature elements
* **Frosted navbar** — sticky, translucent, `blur(20px) saturate(180%)`, with a Spotlight-style search pill and Apple-blue "Log in" pill.
* **Ambient aurora background** — four whisper-quiet radial gradients fixed behind the page, so every frosted surface has something to diffuse.
* **Segmented filter toolbar** — the category rail and tax toggle sit in one pill-shaped frosted control with an edge-fade scroll mask.
* **Glass cards everywhere** — listings, booking widget, reviews, auth forms, invoices, and status badges are translucent white glass with inner highlights.
* **SF-style typography** — `-apple-system / SF Pro` first, with Inter as the cross-platform fallback; tight tracking on large headlines.
* **Apple motion** — pill buttons scale on press, cards lift on hover, sections rise on load; all disabled under `prefers-reduced-motion`.

### Files touched by the re-theme
`public/css/style.css` (rewritten), `views/layouts/boilerplate.ejs`, `views/includes/{navbar,footer,flash}.ejs`, `views/listings/{index,show,new,edit}.ejs`, `views/users/{login,signup}.ejs`, `views/bookings/{index,success}.ejs`, `views/error.ejs`. No backend logic, routes, or form contracts were changed.
